import retrieveGameResults from './handlers/retrieveGameResults.mjs'
import updateGameId from './handlers/updateGameId.mjs'

export default {
    retrieveGameResults,
    updateGameId
}